#!/usr/bin/env python3
"""autorcode — ollama 스타일 로컬 에이전트 CLI.

  autorcode run [model] [prompt]  # 모델 지정 실행/REPL (ollama run 처럼)
  autorcode list                  # 설치된 ollama 모델 목록
  autorcode chat model            # 도구 없는 단순 대화
  autorcode bot                   # 폰 비서 — 텔레그램 폴러(명령+승인)
  autorcode doctor                # 환경 자가진단
  autorcode help                  # 전체 치트시트
"""
import argparse
import hashlib
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

# 설치 위치(심볼릭링크)에 상관없이 harness 패키지를 찾는다
_HERE = os.path.dirname(os.path.realpath(__file__))
sys.path.insert(0, os.path.dirname(_HERE))

from harness import agent_core, approve, bot, config, llm, tools  # noqa: E402
from harness.progress import Progress, short  # noqa: E402


def _host() -> str:
    h = os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434")
    if not h.startswith("http"):
        h = "http://" + h
    return h.rstrip("/")


def _input(prompt: str) -> str:
    """터미널 로케일과 무관하게 raw 바이트로 읽어 디코딩한다.

    input()은 sys.stdin의 로케일 인코딩(보통 utf-8)으로 읽다가 한글 euc-kr 계열
    바이트에서 UnicodeDecodeError로 죽는 경우가 있어 raw 버퍼로 우회한다.
    utf-8 → cp949 순으로 시도하고, 그래도 실패하면 replace 폴백 (예외 없음).

    Ctrl+D나 닫힌 stdin은 빈 바이트열로 읽히며 예외가 없다. 이를 그대로 반환하면
    호출부의 "빈 입력 → 계속" 경로와 합쳐져 프롬프트 루프가 CPU를 태운다.
    입력이 진짜로 끝났음을 EOFError로 알린다.
    """
    sys.stdout.write(prompt)
    sys.stdout.flush()
    raw = sys.stdin.buffer.readline()
    if not raw:
        raise EOFError("stdin 종료")
    for enc in ("utf-8", "cp949"):
        try:
            return raw.decode(enc).strip()
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace").strip()


def _get(path: str, timeout: float = 5):
    req = urllib.request.Request(_host() + path)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def _names() -> list:
    try:
        return [m["name"] for m in _get("/api/tags").get("models", [])]
    except Exception:
        return []


def _loaded() -> set:
    try:
        return {m["name"] for m in _get("/api/ps").get("models", [])}
    except Exception:
        return set()


# 임베딩 전용 모델은 채팅 자동선택/모델선택기에서 뺀다.
_EMBED_HINT = re.compile(
    r"(embed|bge|mxbai|minilm|arctic-embed|gte|jina|voyage|snowflake|"
    r"text-embedding|e5-|all-minilm)", re.I)
_cap_cache: dict = {}


def _capabilities(name: str, timeout: float = 3):
    """ollama /api/show 의 capabilities 목록(없으면 None). 결과는 캐시."""
    if name in _cap_cache:
        return _cap_cache[name]
    caps = None
    try:
        body = json.dumps({"name": name}).encode("utf-8")
        req = urllib.request.Request(
            _host() + "/api/show", data=body,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            caps = json.loads(r.read().decode("utf-8")).get("capabilities")
    except Exception:
        caps = None
    _cap_cache[name] = caps
    return caps


def _is_chat_model(name: str) -> bool:
    """채팅 가능한 모델인가 — 임베딩 전용(bge-m3 등)을 걸러낸다."""
    caps = _capabilities(name)
    if caps:
        return "completion" in caps
    return not _EMBED_HINT.search(name)  # capabilities 미지원 시 이름 패턴 폴백


def _chat_names() -> list:
    """설치된 모델 중 채팅 가능한 것만."""
    return [n for n in _names() if _is_chat_model(n)]


def _auto_pick() -> str:
    """모델 미지정 시 자동선택 — 로드된 것 우선, 임베딩 제외, 알파벳순."""
    chat = set(_chat_names())
    loaded = _loaded() & chat
    pool = loaded | chat
    if pool:
        return sorted(pool, key=lambda n: (n not in loaded, n))[0]
    return config.load().model_fast


def _match_model(arg: str, names: list):
    """arg가 모델 이름인지 판별 — 'phi4'면 'phi4:latest' 매칭, ':' 포함이면 통과."""
    if arg in names:
        return arg
    if arg + ":latest" in names:
        return arg + ":latest"
    matches = [n for n in names if n.startswith(arg + ":")]
    if len(matches) == 1:
        return matches[0]
    return arg if ":" in arg else None


def _openai_models(base_url: str, api_key: str = "", timeout: float = 5) -> list | None:
    """OpenAI 호환 GET /v1/models — vLLM 등 ollama 아닌 서버의 모델 목록."""
    base = (base_url or "").rstrip("/")
    if not base:
        return None
    try:
        req = urllib.request.Request(f"{base if base.endswith('/v1') else base + '/v1'}/models")
        if api_key:
            req.add_header("Authorization", f"Bearer {api_key}")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        items = data.get("data") if isinstance(data, dict) else None
        if not isinstance(items, list):  # ollama 스타일 응답 등 — OpenAI 규격이 아님
            return None
        return [m["id"] for m in items if isinstance(m, dict) and m.get("id")]
    except Exception:
        return None


def model_catalog(timeout: float = 5) -> list:
    """선택 가능한 모델 카탈로그 — ollama 먼저, 그다음 AGENT_BASE_URL 서버.

    항목은 {"name", "base_url", "api_key", "source"} — 선택 즉시 그 서버로
    바로 가도록 백엔드까지 함께 들고 있다(이름만으로는 ollama/원격이 뒤섞여).
    """
    catalog, seen = [], set()

    def add(name, base_url, api_key, source):
        if not name or name in seen:
            return
        seen.add(name)
        catalog.append({"name": name, "base_url": base_url,
                        "api_key": api_key, "source": source})

    for name in _names():
        add(name, _host() + "/v1", "ollama", "ollama")
    custom = os.getenv("AGENT_BASE_URL")
    if custom:
        key = os.getenv("AGENT_API_KEY") or ""
        host = urllib.parse.urlparse(custom).netloc or custom
        for name in _openai_models(custom, key, timeout) or []:
            add(name, custom, key or "ollama", host)
    return catalog


def _resolve_backend(model: str):
    """프로바이더 결정: AGENT_BASE_URL > 모델에 '/' 포함 → OpenRouter > 로컬 ollama.

    AGENT_BASE_URL 이 있어도 ollama 에 실재하는 로컬 모델이면 ollama 로 보낸다 —
    셸에 기본 서버를 하나 두고도 'autorcode run <설치모델>'로 ollama 를 섞어 쓰기 위해서다.
    '/' 포함 모델(OpenRouter 스타일)은 ollama 에 물어 보지 않고 그대로 커스텀으로.
    """
    custom = os.getenv("AGENT_BASE_URL")
    if custom:
        if "/" not in model and _match_model(model, _names()):
            return _host() + "/v1", "ollama"
        return custom, os.getenv("AGENT_API_KEY") or "ollama"
    if "/" in model:
        key = os.getenv("OPENROUTER_API_KEY")
        if not key:
            raise SystemExit(
                "[오류] '/' 포함 모델은 OpenRouter 경유입니다. "
                "OPENROUTER_API_KEY=sk-or-... 를 설정하거나 "
                "(AGENT_BASE_URL/AGENT_API_KEY로 임의 OpenAI 호환 서버도 가능)")
        return "https://openrouter.ai/api/v1", key
    return _host() + "/v1", "ollama"


# ---------------- subcommands ----------------

HELP_TEXT = """autorcode — 모델 라우팅 + 도구 실행 에이전트 (로컬 ollama + 클라우드 공존)

기본 사용
  autorcode list                    설치된 모델 (크기/로드상태)
  autorcode run                     로드된(또는 첫) 모델로 REPL
  autorcode run phi4 "지시"         모델 지정 단발 실행
  autorcode run phi4                그 모델로 REPL
  autorcode run phi4 --yes          승인 자동 — 화이트리스트 밖 명령도 자동 승인(민감경로·탈출패턴 제외)
  autorcode run phi4 --quiet        과정 출력 끄기 (기본: 스텝마다 실시간 표시)
  autorcode run phi4 --details      도구 결과 미리보기 확대 (3줄 → 12줄)
  autorcode run phi4 --no-stream    SSE 미지원 서버에 일반 JSON 요청
  autorcode run qwen3.6:35b --reasoning-effort none   thinking 모델 추론 끔 (답 잘림 방지)
  autorcode run phi4 --max-tokens 32768               응답 출력 토큰 상한 늘리기
  autorcode run phi4 --session h.jsonl   히스토리 저장/재개
  autorcode run phi4 --no-session         기본 자동 세션(작업폴더별) 끔
  autorcode chat phi4               도구 없는 단순 채팅
  autorcode tui [phi4]              전체화면 TUI (opencode 스타일, Textual)
  autorcode doctor                  서버/메모리/GPU 자가진단

GPU 없이 즉시 사용 (OpenRouter — 모델명 '/' 포함)
  OPENROUTER_API_KEY=sk-or-... autorcode run deepseek/deepseek-chat-v3 "분석해"
  ollama가 꺼져 있어도 OPENROUTER_API_KEY만 있으면 자동 전환됨
  기본 클라우드 모델은 OPENROUTER_MODEL(기본 deepseek/deepseek-chat-v3)로 변경

실행 과정
  모델 요청 즉시 대기 표시 → 응답 수신량(글자 수) → 도구 실행 → 결과/시간 표시
  터미널에서는 경과 시간 갱신, 파이프/로그에서는 5초마다 진행 상태 한 줄
  진행은 stderr, 최종 답변은 stdout. 원시 추론이나 미완성 JSON은 표시하지 않음
  대화 중 /status /tools /steps on|off /details on|off /help 사용 가능
  업데이트 뒤에는 exit 후 다시 실행해야 새 기능이 적용됨

TUI 모드 (autorcode tui · Textual 필요: pip install 'autorcode[tui]')
  Enter 전송 · Ctrl+P 팔레트 · F2 모델 · F3 세션 · Ctrl+T 테마 · Ctrl+L 지우기
  Ctrl+G 그림 첨부(컬러 미리보기 + OCR) · Esc 작업 취소 · Ctrl+Q 종료
  /voice 음성방 — 폰/PC 브라우저 마이크와 같은 대화(터미널은 자막·타이핑 참여)
  /duet <주제> 봇끼리 대화 — 로이와 봇이 자동 티키타카 (중단 /duet stop)
  슬래시: /help /model /sessions /theme /status /tools /clear /auto /pause /resume /cancel /compact /copy /image /voice /duet /quit
  모델 선택기: ollama 설치분 + OpenAI 호환 서버(GET /v1/models)를 한 목록으로
    — 선택하면 그 서버 백엔드로 즉시 전환 (AGENT_BASE_URL 기본 서버 포함)
  도구 실행은 카드, 파일 편집은 diff, 승인은 모달로 표시

도구 프로토콜 (네이티브 function calling 우선, 불가능한 서버는 JSON 규식)
  네이티브: OpenAI tools 스키마 전달 → tool_calls 로 도구 호출 (AGENT_NATIVE_TOOLS=0 으로 끔)
  JSON: {"tool":"bash","args":{"command":"ls"}} / {"actions":[...]} / {"done":true,"answer":"..."}
  주요 도구: bash / read_file / write_file / edit_file / list_dir / grep_files
      web_search(웹검색·키불필요) / web_fetch(웹페이지) / youtube(메타+자막)
      remember / recall / forget(영속 기억 — 파악한 사실 저장, 재탐색 방지)
  중간 정지: 실행 중 언제든 Ctrl+C 로 취소 (REPL은 계속, 진행 중 도구는 백그라운드 정리)
격리: cwd 샌드박스 + 차단패턴(sudo rm -rf /, curl|sh, 포크폭탄…) +
      RLIMIT(CPU/MEM/FSIZE/NPROC) + 타임아웃 시 프로세스그룹째 KILL +
      웹 도구 SSRF 가드(사설 IP·내부 포트 접근 거부)

권한 모드 (AGENT_PERMS)
  balanced(기본)  읽기·조회(systemctl status 등) 자동 허용, 저술적(rm·python3·git·curl…)은 y/N 승인
  yolo            블랙리스트만 적용
  strict          bash·파일쓰기 전부 승인 필요

환경변수 (AGENT_*)
  MODEL_FAST(기본 phi4:latest) MODEL_SMART(qwen3.8:27b-hunmin-64k)
  API_TIMEOUT(120) MAX_STEPS(0=무제한) BASH_TIMEOUT(30) CONTEXT_TOKENS(40000)
  MAX_TOKENS(8192) REASONING_EFFORT(로컬 기본 none) RLIMIT_MEM_MB(4096) SESSION, PERMS
  MEMORY_FILE(기본 ~/.autorcode/memory.txt) MEMORY_MAX_CHARS(3000)
  SHOW_STEPS(1) SHOW_DETAILS(0) STREAM(1) — 0/1로 표시·스트리밍 설정
  OPENROUTER_API_KEY=sk-or-...  OPENROUTER_MODEL(기본 deepseek/deepseek-chat-v3)
  ~/.autorcode/env 에 KEY=VALUE 한 줄로 저장 가능 (AGENT_BASE_URL 등 기본 설정)
    — sh export / systemd Environment 가 항상 우선. API 토큰은 넣지 말 것

유료 API 전환
  AGENT_BASE_URL=https://api.openai.com/v1 AGENT_API_KEY=sk-... \\
    autorcode run gpt-4o "분석해"
"""


def cmd_help(_args):
    print(HELP_TEXT)
    return 0


def cmd_list(_args):
    try:
        models = _get("/api/tags").get("models", [])
    except Exception as e:
        print(f"ollama 서버에 연결할 수 없습니다 ({_host()}): {e}")
        print("  시작: ollama serve  (또는 sudo systemctl enable --now ollama)")
        print("  참고: autorcode run은 OPENROUTER_API_KEY가 있으면 ollama 없이도 동작합니다")
        return 1
    loaded = _loaded()
    print(f"{'NAME':<28} {'SIZE':>7}  {'STATUS'}")
    for m in sorted(models, key=lambda x: x["name"]):
        gb = m.get("size", 0) / 2**30
        print(f"{m['name']:<28} {gb:>6.1f}G  {'●loaded' if m['name'] in loaded else ''}")
    return 0


def cmd_doctor(_args):
    print(f"python   : {sys.version.split()[0]}  {sys.executable}")
    print(f"cli 위치 : {os.path.dirname(_HERE)}")
    try:
        models = _get("/api/tags").get("models", [])
        loaded = _loaded()
        print(f"ollama   : {_host()} OK — 모델 {len(models)}개, 로드중 {sorted(loaded)}")
    except Exception as e:
        print(f"ollama   : {_host()} 연결실패 ({e}) — `ollama serve` 실행 필요")
    try:
        mi = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            mi[k] = int(v.split()[0])
        print(f"메모리   : total {mi['MemTotal']//2**20}GB / avail {mi['MemAvailable']//2**20}GB")
    except Exception:
        pass
    print(f"경고     : " + ("AGENT_BASE_URL/OLLAMA_HOST 미설정 → autorcode run은 ollama 기본으로 동작" if not (os.getenv("AGENT_BASE_URL") or os.getenv("OLLAMA_HOST")) else "AGENT_BASE_URL 설정됨 — autorcode run이 그 엔드포인트 우선 사용"))
    key = os.getenv("OPENROUTER_API_KEY")
    if key:
        print(f"openrouter: 키 설정됨 (…{key[-4:]}) — '/' 모델(클라우드) 즉시 사용 가능")
    return 0
def cmd_report(_args):
    from harness import telegram
    return telegram.run_report()


def cmd_mcp(_args):
    from harness import mcp as mcp_mod
    print(f"설정     : {mcp_mod.config_path()}")
    servers = mcp_mod.mcp_servers()
    if not servers:
        print("등록된 MCP 서버 없음 — 예시:")
        print('  {"mcpServers": {"filesystem": {"command": "npx", "args": ["-y", "@modelcontextprotocol/server-filesystem", "$HOME"]}}}')
        return 0
    total = 0
    for name, tools in servers.items():
        print(f"{name}: {len([t for t in tools if not t.startswith('[')])}개 도구")
        for t in tools:
            print(f"  - {t}")
        total += len(tools)
    print(f"합계 {total}개 도구 — 에이전트가 'mcp_<서버>_<도구>' 이름으로 호출")
    return 0


def _confirmer(progress=None, mode="auto"):
    """승인 경로를 고른다.

    mode:
      auto     TTY → 텔레그램 → 없음(=전부 거부). 기본.
      telegram 텔레그램 강제. TTY 에서 돌려도 폰으로 승인받는다.
      tty      터미널 강제. 텔레그램 설정을 있어도 쓰지 않는다.
      deny     승인 자체를 금지. 확인이 필요한 호출은 전부 거부된다.

    auto 가 기본인 이유: 폰 게이트는 폴러 스레드와 타임아웃이 있어서 방해가 되고,
    TTY 가 없는 환경(systemd, bridge)에서만 값어치가 있다. 하지만 터미널에서
    작업을 던져놓고 폰으로 승인하는 workflow 도 있으므로 telegram 으로 강제할 수
    있게 해 둔다.
    """
    if mode == "tty":
        return _ask
    if mode == "deny":
        return None
    if mode == "telegram":
        gate = approve.build_from_config()
        if gate is None:
            # 텔레그램을 강제했는데 못 쓰면 조용히 거부로 넘어가면 안 된다.
            # 승인을 기다릴 것 같았는데 아무 것도 안 오는 상황이 최악이다.
            raise SystemExit(
                "[오류] --approve telegram 을 지정했지만 승인 게이트를 쓸 수 없습니다. "
                "텔레그램 설정(~/autorcode/telegram.json)을 확인하세요. "
                "설정 없이 진행하면 승인이 필요한 작업은 전부 거부됩니다."
            )
        if progress is not None:
            progress.event("  [승인 경로] 텔레그램 (포트 열지 않음)")
        return gate
    if mode != "auto":
        raise SystemExit(f"[오류] --approve 값이 잘못됨: {mode!r} "
                         "(auto|telegram|tty|deny)")

    if sys.stdin.isatty():
        return _ask
    gate = approve.build_from_config()
    if gate is None:
        return None
    if progress is not None:
        progress.event("  [승인 경로] 텔레그램 (포트 열지 않음)")
    return gate


def _is_local(base_url: str) -> bool:
    """로컬 ollama 엔드포인트인지 — thinking 기본값(none)을 켤지 판단한다."""
    return "127.0.0.1" in base_url or "localhost" in base_url


def _make_cfg(model: str, rest) -> config.Config:
    cfg = config.load()
    cfg.base_url, cfg.api_key = _resolve_backend(model)
    cfg.model_fast = model
    cfg.model_smart = model
    # 로컬 thinking 모델(qwen3 등)은 추론이 max_tokens를 다 써서 답이 잘린다.
    # 스트릭트 JSON 하네스에서는 추론을 끄는 게 맞다 (클라우드는 건드리지 않음).
    if not cfg.reasoning_effort and _is_local(cfg.base_url):
        cfg.reasoning_effort = "none"
    if getattr(rest, "max_tokens", None):
        cfg.max_tokens = rest.max_tokens
    if getattr(rest, "reasoning_effort", None) is not None:
        cfg.reasoning_effort = rest.reasoning_effort
    if rest.yes:
        cfg.auto_yes = True
    if getattr(rest, "auto", False):
        cfg.auto_smart = True
    if getattr(rest, "quiet", False):
        cfg.show_steps = False
    if getattr(rest, "details", False):
        cfg.show_details = True
    if getattr(rest, "no_stream", False):
        cfg.stream = False
    if rest.session:
        cfg.session_file = rest.session
    elif not getattr(rest, "no_session", False):
        # 기본 세션: 작업 디렉터리 기준 — 이전 파악 내용을 이어서 기억
        path = os.path.expanduser(
            f"~/.autorcode/session_{hashlib.md5(cfg.workspace_root.encode()).hexdigest()[:10]}.jsonl")
        os.makedirs(os.path.dirname(path), exist_ok=True)
        cfg.session_file = path
    for warning in config.preflight(cfg):
        print(warning, file=sys.stderr)
    return cfg


def cmd_run(args):
    display = config.load()
    progress = Progress(display.show_steps and not args.quiet,
                        display.show_details or args.details)
    with progress.activity("[연결] 로컬 모델 목록 확인"):
        catalog = model_catalog()
    names = [e["name"] for e in catalog]
    model, prompt = args.model, list(args.prompt or [])
    cloud_key = os.getenv("OPENROUTER_API_KEY")
    custom_base = os.getenv("AGENT_BASE_URL")
    if not names and not cloud_key and not custom_base:
        # 조용히 죽은 127.0.0.1:11434로 3회 재시도한 뒤 "Connection refused"만
        # 남기는 대신, 해결 방법을 안내하고 즉시 끝낸다.
        print("[오류] ollama({})에 연결할 수 없고 OPENROUTER_API_KEY도 없어 "
              "사용할 LLM 백엔드가 없습니다.\n"
              "  1) 로컬 모델: sudo systemctl enable --now ollama\n"
              "  2) 클라우드  : export OPENROUTER_API_KEY=sk-or-... "
              "→ autorcode run만 사용 가능\n"
              "  3) 임의 서버: export AGENT_BASE_URL=https://... AGENT_API_KEY=...".format(_host()),
              file=sys.stderr)
        return 1
    if not names:
        if cloud_key:
            if "/" in model:
                pass  # 명시적 클라우드 모델 → 그대로 진행
            elif not model:
                model = os.getenv("OPENROUTER_MODEL", "deepseek/deepseek-chat-v3")
                print(f"[연결] ollama 응답 없음 → OpenRouter 사용 ({model})", file=sys.stderr)
            else:
                print(f"[오류] ollama가 응답하지 않아 로컬 모델 {model!r}을 쓸 수 없습니다. "
                      "클라우드로 실행하려면 'deepseek/deepseek-chat-v3' 같은 '/' 모델을 지정하세요.",
                      file=sys.stderr)
                return 1
    elif model and "/" not in model:
        resolved = _match_model(model, names)
        if resolved is None:  # 모델 아닌 단어 → 프롬프트로 강등
            prompt.insert(0, model)
            model = ""
        else:
            model = resolved
    if not model:
        model = _auto_pick()
        if names and model not in names:  # ollama 기본값이 카탈로그에 없으면(서버만 살아있는 등)
            model = names[0]             # 실재하는 첫 모델로 — 조용한 404 대신
    cfg = _make_cfg(model, args)
    agent = agent_core.Agent(cfg, confirmer=_confirmer(progress, getattr(args, "approve", "auto")), progress=progress)
    head = f"autorcode run {model}  (권한 {cfg.permissions_mode}{'/auto-yes' if cfg.auto_yes else ''}{'/자율' if getattr(cfg, 'auto_smart', False) else ''})"

    try:
        if prompt:
            progress.event(head)
            print(agent.run(" ".join(prompt)), flush=True)
            return 0

        print(f"=== {head} === 도구 {len(tools.TOOLS)}개 · /help 도움말 · exit 종료", flush=True)
        while True:
            try:
                task = _input("당신> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                return 0
            if not task:
                continue
            if task.lower() in ("exit", "quit", "종료"):
                return 0
            if repl_command(task, agent):
                continue
            print(f"\n{agent.run(task)}\n", flush=True)
    finally:
        agent.close()


def repl_command(task, agent):
    """로컬 명령은 모델 호출 없이 즉시 처리한다."""
    parts = task.split()
    command = parts[0] if parts else ""
    if command not in ("/help", "/status", "/tools", "/steps", "/details"):
        return False
    if command == "/help":
        print("/status 상태 · /tools 도구 목록 · /steps on|off 과정 표시 · "
              "/details on|off 결과 확대 · exit 종료")
    elif command == "/tools":
        print(tools.schema_text())
    elif command == "/status":
        cfg = agent.cfg
        print(f"모델: {cfg.model_fast} / {cfg.model_smart}\n작업 위치: {cfg.workspace_root}\n"
              f"도구 {len(tools.TOOLS)}개 · 권한 {cfg.permissions_mode} · "
              f"과정 {'on' if agent.progress.enabled else 'off'} · "
              f"상세 {'on' if agent.progress.details else 'off'} · "
              f"SSE {'on' if cfg.stream else 'off'}")
    elif len(parts) == 2 and parts[1] in ("on", "off"):
        value = parts[1] == "on"
        if command == "/steps":
            agent.cfg.show_steps = agent.progress.enabled = value
        else:
            agent.cfg.show_details = agent.progress.details = value
        print(f"{command}: {parts[1]}")
    else:
        print(f"사용법: {command} on|off")
    return True


def _ask(why: str) -> bool:
    try:
        print(f"\n[승인?] {short(why, 400)}\n  y/N: ", end="", file=sys.stderr, flush=True)
        return input().strip().lower() in ("y", "yes", "ㄱ")
    except EOFError:
        return False


def cmd_chat(args):
    names = _names()
    model = _match_model(args.model, names) or args.model
    messages = [{"role": "system", "content": "간결하게 한국어로 답한다."}]
    base_url, api_key = _resolve_backend(model)
    effort = args.reasoning_effort
    if effort is None:
        effort = "none" if _is_local(base_url) else ""
    max_tokens = args.max_tokens or int(os.getenv("AGENT_MAX_TOKENS", "8192"))
    client = llm.OpenAICompatibleLLM(base_url, api_key, 120, 2, 0.3,
                                     max_tokens, effort)
    print(f"=== autorcode chat {model} (도구 없음/{'OpenRouter' if '/' in model else 'ollama'}) === exit 종료")
    while True:
        try:
            q = _input("당신> ").strip()
        except (EOFError, KeyboardInterrupt):
            return 0
        if q.lower() in ("exit", "quit", ""):
            return 0
        messages.append({"role": "user", "content": q})
        try:
            reply = client.chat(messages, model)
            a = reply.content
        except llm.LLMError as e:
            print(f"[오류] {e}")
            continue
        messages.append({"role": "assistant", "content": a})
        print(f"보조개> {a}\n")


def cmd_tui(args) -> int:
    """전체화면 TUI (Textual) — opencode 스타일 인터페이스.

    기존 run 과 같은 하네스를 쓰되, 진행 상황을 카드/상태바로 그리고
    승인은 모달로, 파일 편집은 diff 로 보여준다. Textual 은 선택 의존성이다.
    """
    config.setup_logging(getattr(args, "verbose", False))
    from harness import tui
    model = args.model or ""
    catalog = model_catalog()
    names = [e["name"] for e in catalog]
    if model and "/" not in model:
        resolved = _match_model(model, names)
        if resolved:
            model = resolved
    if not model:
        model = _auto_pick()
        if names and model not in names:  # ollama 기본값이 카탈로그에 없으면(서버만 살아있는 등)
            model = names[0]             # 실재하는 첫 모델로 — 조용한 404 대신
    cfg = _make_cfg(model, args)
    # 카탈로그 엔트리의 백엔드를 그대로 쓴다 — 같은 목록에 ollama 와 원격
    # 서버 모델이 섞여 있으므로 이름만으로 재추론하면 서버가 뒤바뀔 수 있다.
    entry = next((e for e in catalog if e["name"] == model), None)
    if entry:
        cfg.base_url, cfg.api_key = entry["base_url"], entry["api_key"]
        if _is_local(cfg.base_url) and not getattr(args, "reasoning_effort", None):
            cfg.reasoning_effort = "none"
    return tui.run(cfg, model=model)


def cmd_bot(args) -> int:
    """폰 비서: 이름 있는 봇 토큰의 폴러 하나로 승인+명령을 처리한다."""
    config.setup_logging(args.verbose)
    b = bot.build_bot() if getattr(args, "token", None) is None else None
    if b is None:
        if getattr(args, "token", None):
            # 명시 토큰 = 테스트/디버그 경로. 그래도 허용 chat 이 있어야 막는 목적이 산다.
            token = args.token
            chat = (args.chat or "").strip()
            if not chat:
                print("[오류] 토큰을 지정하려면 --chat(허용 chat id)도 필요합니다", file=sys.stderr)
                return 1
            from harness.approve import DEFAULT_TIMEOUT
            from harness.bot import Bot
            b = Bot(token, [int(chat)])
        else:
            print("[오류] 폰 비서 설정이 없습니다. 환경변수 AGENTUPBOT_TOKEN(+AGENTUPBOT_CHAT) "
                  "또는 ~/.autorcode/bot.json (token + allowedChatIds) "
                  "또는 기존 ~/.autorcode/telegram.json", file=sys.stderr)
            return 1
    b.start()
    print(f"[봇] 폴러 시작 — 허용 {len(b._allowed)}명 · Ctrl+C 로 종료", file=sys.stderr)
    try:
        if b._thread is not None:
            b._thread.join()
    except KeyboardInterrupt:
        print("\n[봇] 종료", file=sys.stderr)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(prog="autorcode", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("run", help="모델 실행: autorcode run [model] [prompt]")
    run_parser = p
    p.add_argument("model", nargs="?", default="", help="ollama 모델명 (생략 시 로드/목록 우선)")
    p.add_argument("prompt", nargs="*", help="한 번 실행할 지시")
    p.add_argument("--yes", action="store_true", help="승인 자동")
    p.add_argument("--approve", choices=("auto", "telegram", "tty", "deny"), default="auto",
                   help="승인 경로 (기본 auto: TTY→텔레그램→거부). "
                        "telegram=터미널이어도 폰으로, tty=텔레그램 있어도 터미널, "
                        "deny=전부 거부")
    p.add_argument("--auto", action="store_true", help="자율 모드 — 파괴적 명령만 승인, 나머지 자동")
    p.add_argument("--quiet", action="store_true", help="과정 출력 끔 (결과만)")
    p.add_argument("--details", action="store_true", help="도구 결과 미리보기 확대")
    p.add_argument("--no-stream", action="store_true", help="SSE 대신 일반 JSON 응답 사용")
    p.add_argument("--max-tokens", type=int, default=None,
                   help="응답 최대 출력 토큰 (기본 AGENT_MAX_TOKENS=8192)")
    p.add_argument("--reasoning-effort", default=None,
                   help="thinking 모델 추론 제어: none=추론 끔(로컬 기본) · low/medium/high")
    p.add_argument("--verbose", action="store_true", help="진단 로그 출력")
    p.add_argument("--session", help="히스토리 jsonl")
    p.add_argument("--no-session", action="store_true", help="기본 세션 저장 끔")
    p.set_defaults(fn=cmd_run, cmd="run")

    p = sub.add_parser("tui", help="전체화면 TUI (Textual) — opencode 스타일")
    p.add_argument("model", nargs="?", default="", help="ollama 모델명 (생략 시 로드/목록 우선)")
    p.add_argument("--yes", action="store_true", help="승인 자동 (모달 건너뜀)")
    p.add_argument("--approve", choices=("auto", "telegram", "tty", "deny"), default="auto",
                   help="승인 경로 (TUI 는 자체 모달 사용 — deny 면 전부 거부)")
    p.add_argument("--auto", action="store_true", help="자율 모드 — 파괴적 명령만 승인")
    p.add_argument("--quiet", action="store_true", help="(TUI 에선 무시 — 카드 접기로 대체)")
    p.add_argument("--details", action="store_true", help="도구 결과 미리보기 확대")
    p.add_argument("--no-stream", action="store_true", help="SSE 대신 일반 JSON 응답 사용")
    p.add_argument("--max-tokens", type=int, default=None,
                   help="응답 최대 출력 토큰 (기본 AGENT_MAX_TOKENS=8192)")
    p.add_argument("--reasoning-effort", default=None,
                   help="thinking 모델 추론 제어: none=추론 끔(로컬 기본) · low/medium/high")
    p.add_argument("--verbose", action="store_true", help="진단 로그 출력")
    p.add_argument("--session", help="히스토리 jsonl")
    p.add_argument("--no-session", action="store_true", help="기본 세션 저장 끔")
    p.set_defaults(fn=cmd_tui, cmd="tui")

    p = sub.add_parser("list", help="로컬 모델 목록")
    p.set_defaults(fn=cmd_list)
    p = sub.add_parser("chat", help="도구 없는 단순 채팅")
    p.add_argument("model")
    p.add_argument("--max-tokens", type=int, default=None,
                   help="응답 최대 출력 토큰 (기본 AGENT_MAX_TOKENS=8192)")
    p.add_argument("--reasoning-effort", default=None,
                   help="thinking 모델 추론 제어: none=추론 끔(로컬 기본)")
    p.set_defaults(fn=cmd_chat)
    p = sub.add_parser("doctor", help="환경 진단")
    p.set_defaults(fn=cmd_doctor)
    p = sub.add_parser("mcp", help="MCP 서버/도구 목록 (~/.autorcode/mcp.json)")
    p.set_defaults(fn=cmd_mcp)
    p = sub.add_parser("report", help="서버 상태 리포트 — 텔레그램 전송(토큰 있으면) 또는 stdout")
    p.set_defaults(fn=cmd_report)
    p = sub.add_parser("bot", help="폰 비서 — 텔레그램 폴러(명령+승인) 실행")
    p.add_argument("--token", default=None, help="수신용 봇 토큰 (기본: AGENTUPBOT_TOKEN env → ~/.autorcode/bot.json → telegram.json)")
    p.add_argument("--chat", default=None, help="허용 chat id (토큰 직접 지정 시 필수)")
    p.add_argument("--verbose", action="store_true", help="진단 로그 출력")
    p.set_defaults(fn=cmd_bot)
    p = sub.add_parser("help", help="전체 치트시트")
    p.set_defaults(fn=cmd_help)

    # run의 모델/프롬프트 사이에도 --details 등의 옵션을 둘 수 있다.
    args = (run_parser.parse_intermixed_args(sys.argv[2:])
            if sys.argv[1:2] == ["run"] else ap.parse_args())
    if args.cmd in ("run", "chat"):
        config.setup_logging(getattr(args, "verbose", False))
    return args.fn(args) or 0


if __name__ == "__main__":
    sys.exit(main())
