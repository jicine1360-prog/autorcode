"""권한 정책 — 블랙리스트(안전) 위에 화이트리스트 + 승인 게이트를 얹는다.

모드 (AGENT_PERMS):
- yolo      : 화이트리스트/승인 없음, safety.py 블랙리스트만 (학습용)
- balanced  : 기본값. bash 실행파일 화이트리스트 + 저술적 명령은 승인(확인) 요구
- strict    : balanced + bash 전체·파일쓰기까지 승인 요구

승인 결정값: ("allow", None) | ("confirm", 사유) | ("deny", 사유)
confirm은 사용자 승인 게이트(터미널 모달·웹·텔레그램)로 보내고, deny는 승인
없이 확정 거부다. 화이트리스트 밖 바이너리는 confirm — 사용자가 화면에서
직접 허용/거부한다(예: ollama). 단 민감 경로·실행 탈출·파괴적 패턴이 섞이면
화이트리스트 밖이라도 deny — 승인으로도 열리지 않는다.
deny는 모델에게 오류로 환류되어 스스로 경로를 바꿀 수 있게 힌트를 담는다.
"""
import os
import re

ALLOW_BIN = {
    "ls", "cat", "head", "tail", "wc", "sort", "uniq", "cut", "tr", "grep",
    "rg", "find", "pwd", "cd", "date", "echo", "printf", "df", "du", "ps", "stat",
    "file", "diff", "which", "whoami", "id", "uname", "uptime", "free", "tree",
    "env", "sed", "awk", "basename", "dirname", "seq", "true", "false", "test",
    "less", "ss", "netstat", "lsof", "nproc", "lsblk", "lscpu", "lspci",
    "lsusb", "blkid", "getent", "locale",
}
# 본래 상태 변경이 가능하지만 인자/옵션을 조사해 "읽기 전용 호출"일 때만 무승인 허용.
# 조건이 False면 CONFIRM_BIN처럼 승인을 요구한다.
_SYSCTL_RO = {"status", "is-active", "is-enabled", "is-failed", "show", "list-units",
              "list-unit-files", "list-timers", "list-sockets", "list-jobs",
              "list-dependencies", "get-default", "cat", "list-machines"}
_READONLY_BIN = {
    "systemctl": lambda c: _word(c, 1) in _SYSCTL_RO,
    "journalctl": lambda c: "--vacuum" not in c,
    "dmesg": lambda c: not re.search(r"-(?:c|C)(?:\s|$)", c),
    "ip": lambda c: bool(re.search(r"\b(?:show|sh|list)\b", c)),
    "hostname": lambda c: len([w for w in c.split() if not w.startswith("-")]) <= 1,
    "hostnamectl": lambda c: _word(c, 1) == "status",
    "ldconfig": lambda c: False,  # /etc/ld.so.cache 갱신 — 항상 승인 필요
}
CONFIRM_BIN = {
    "rm", "mv", "cp", "mkdir", "rmdir", "touch", "chmod", "chown", "ln", "tar",
    "zip", "unzip", "git", "python", "python3", "node", "npm", "npx", "pip",
    "pip3", "make", "cargo", "kill", "pkill", "nohup", "systemctl", "curl", "wget",
}


def _word(cmd: str, idx: int) -> str:
    words = [w for w in cmd.split() if not w.startswith("-")]
    return words[idx] if 0 <= idx < len(words) else ""
_PIPE_SPLIT = re.compile(r"&&|\|\||;|\||\$\(")

# 화이트리스트 바이너리라도 이 인자/패턴은 임의 실행 탈출구다
_RISKY_ARGS = [
    (re.compile(r"\bfind\b.*(?:-exec(?:dir)?|-delete|-ok)\b", re.I), "find -exec/-delete"),
    (re.compile(r"\bsed\b.*s/[^/]*/[^/]*/[a-zA-Z]*e\b", re.I), "sed /e 플래그(명령 실행)"),
    (re.compile(r"\bawk\b.*\bsystem\s*\(", re.I), "awk system()"),
    (re.compile(r"\bgit\b\s+\S*\s*-c\b.*core\.(pager|editor|sshCommand)", re.I), "git -c 실행설정"),
    (re.compile(r"\b(tar|zip)\b.*--use-(gzip|compress|checkpoint)-command", re.I), "아카이브 커맨드 플래그"),
]

# 허용 바이너리라도 이 경로 참조는 읽기/쓰기 모두 거부 (bash 명령 문자열 스캔)
_SENSITIVE = re.compile(
    r"(\.ssh/|\.ssh\b|id_rsa|id_ecdsa|id_ed25519|authorized_keys|\.aws/|\.gnupg/|"
    r"\.config/gcloud|\.config/gh|\.azure/|\.netrc|\.npmrc|/etc/(shadow|sudoers)|"
    r"\.kube/config|service.?account|secrets?manager)", re.I)


def check_bash(cmd: str, mode: str):
    if mode == "yolo":
        return "allow", None
    if _SENSITIVE.search(cmd):
        return ("deny",
                "민감 경로/자격증명 참조가 감지됨(.ssh, .aws, .netrc 등) — 이 하네스는 "
                "bash에서 자격증명 파일 접근을 의도적으로 거부한다")
    for pat, why in _RISKY_ARGS:
        if pat.search(cmd):
            return "deny", f"화이트리스트 바이너리의 실행 탈출구 차단: {why}"
    tokens0 = [s.strip() for s in _PIPE_SPLIT.split(cmd) if s.strip()]
    if not tokens0:
        return "allow", None
    # $(...)·(서브셸) 분해 시 남는 괄호를 제거한다 — 안 지우면 'date)' 가
    # 화이트리스트 밖으로 오탐되어 승인창이 뜬다.
    firsts = [os.path.basename(s.split()[0].strip("()")) for s in tokens0]
    if mode == "strict":
        # strict 는 쓰기·상태 변경을 승인으로 막는 모드다. 그런데 읽기 조회까지
        # 매번 텔레그램 승인을 요구하면 원격 관리 에이전트가 상태 조회조차 못
        # 하고 대기만 한다. 읽기 성격의 명령(ALLOW_BIN 과 통과한 _READONLY_BIN)
        # 은 무승인으로 통과시키고, 나머지는 전부 승인으로 보낸다 — 게이트 대상은
        # '변경'이다.
        for b in firsts:
            if b in _READONLY_BIN:
                if _READONLY_BIN[b](cmd):
                    continue
                return "confirm", f"strict 모드: '{b}' 상태 변경 호출 — 승인 필요"
            if b in ALLOW_BIN:
                continue
            if b in CONFIRM_BIN:
                return "confirm", "strict 모드: 상태 변경·쓰기 명령 승인 필요"
            if is_destructive(cmd):
                return ("deny",
                        f"'{b}'는 화이트리스트 밖 + 파괴적 패턴 — 승인으로도 허용하지 않는다")
            return ("confirm",
                    f"'{b}'는 화이트리스트 밖 — 승인하면 실행합니다. "
                    f"읽기 허용목록: {', '.join(sorted(list(ALLOW_BIN)[:12]))}… "
                    f"(민감 경로·파괴적 패턴은 승인으로도 불가)")
        return "allow", None
    for b in firsts:
        if b in _READONLY_BIN:
            if _READONLY_BIN[b](cmd):
                continue  # 읽기 전용 호출 → 승인 없이 허용
            return "confirm", f"'{b}' 상태 변경 호출 — 승인 필요 (읽기 전용 인자면 자동 허용)"
        if b in CONFIRM_BIN:
            return "confirm", f"저술적 명령 '{b}' 승인 필요"
        if b not in ALLOW_BIN:
            if is_destructive(cmd):
                return ("deny",
                        f"'{b}'는 화이트리스트 밖 + 파괴적 패턴 — 승인으로도 허용하지 않는다")
            return ("confirm",
                    f"'{b}'는 화이트리스트 밖 — 승인하면 실행합니다. "
                    f"읽기 허용목록: {', '.join(sorted(list(ALLOW_BIN)[:12]))}… "
                    f"(민감 경로·파괴적 패턴은 승인으로도 불가)")
    return "allow", None


def check_write(mode: str):
    if mode == "strict":
        return "confirm", "strict 모드: 파일쓰기 승인 필요"
    return "allow", None


# --- 자율 모드(--auto): 확인은 요구되지만 파괴적이지 않은 명령을 자동 승인한다 ---
_DESTRUCTIVE = re.compile(
    r"(rm\s+[^;|&]*(?:-[a-zA-Z]*[rf]|-[rf])\s+(?:/|~|\$HOME)\b"
    r"|rm\s+-[a-zA-Z]*r[a-zA-Z]*f|mkfs|dd\s+[^;|&]*\bof=|shutdown|reboot|poweroff|halt\b"
    r"|pkill|killall|kill\s+-9\s+(?:1\b|-1\b)|systemctl\s+(?:stop|disable|mask)\b"
    r"|(?:curl|wget)\b[^;|]*\|\s*(?:sudo\s+)?(?:ba)?sh\b"
    r"|git\s+push\s+[^;|]*(?:--force\b|-f\b)|chmod\s+-R|> ?/dev/[sh]d[a-z])", re.I)


def is_destructive(cmd: str) -> bool:
    """자율 모드에서 자동 승인을 거부할 명령인지 판별 (True=사람 확인 필요)."""
    return bool(_DESTRUCTIVE.search(cmd))
